"""Use an exported Wijaya Kusuma LightGBM model for an exact lead time."""

from datetime import date, timedelta
from pathlib import Path
import pickle

import numpy as np
import pandas as pd


def load_lead_time_model(model_dir, lead_time_days):
    """Load a model from the application's trusted model directory."""
    if type(lead_time_days) is not int or lead_time_days <= 0:
        raise ValueError("Lead time harus berupa bilangan bulat positif.")
    model_path = Path(model_dir) / f"lightgbm_{lead_time_days}d.pkl"
    if not model_path.is_file():
        raise ValueError(f"Model LightGBM untuk lead time {lead_time_days} hari belum tersedia.")
    with model_path.open("rb") as handle:
        bundle = pickle.load(handle)
    metadata = bundle["metadata"]
    if metadata["horizon_days"] != lead_time_days or "lead_time" not in metadata.get("forecast_uses", []):
        raise ValueError(f"Model {model_path.name} belum dikonfigurasi untuk lead time {lead_time_days} hari.")
    return bundle


def predict_lead_time(bundle, forecast_date, features):
    """Predict total units for one or more groups from features available at the forecast date."""
    metadata = bundle["metadata"]
    horizon = metadata["horizon_days"]
    origin = date.fromisoformat(forecast_date)
    matrix = pd.DataFrame([features] if isinstance(features, dict) else features)
    missing = [name for name in metadata["feature_names"] if name not in matrix.columns]
    if matrix.empty or missing:
        raise ValueError(f"Fitur prediksi kosong atau tidak lengkap: {missing}.")
    matrix = matrix[metadata["feature_names"]].apply(pd.to_numeric, errors="raise").astype(float)
    required = [name for name in matrix.columns if name not in metadata["nullable_features"]]
    if matrix[required].isna().any().any() or np.isinf(matrix.to_numpy()).any():
        raise ValueError("Fitur prediksi berisi nilai kosong atau tak terhingga yang tidak didukung.")
    for column, levels in metadata["category_levels"].items():
        if not matrix[column].isin(levels.values()).all():
            raise ValueError(f"Kode fitur {column} tidak ditemukan di metadata model.")
    if not matrix["karat"].isin(metadata["known_karat"]).all():
        raise ValueError("Kadar tidak ditemukan di metadata model.")
    predictions = np.maximum(0.0, bundle["model"].predict(matrix, num_threads=1))
    return [
        {
            "forecast_date": origin.isoformat(),
            "forecast_start": (origin + timedelta(days=1)).isoformat(),
            "forecast_end": (origin + timedelta(days=horizon)).isoformat(),
            "lead_time_days": horizon,
            "predicted_units": float(units),
        }
        for units in predictions
    ]
